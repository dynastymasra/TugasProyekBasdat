-- phpMyAdmin SQL Dump
-- version 3.2.0.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: May 28, 2012 at 02:10 PM
-- Server version: 5.1.37
-- PHP Version: 5.3.0

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `db_tepe`
--

-- --------------------------------------------------------

--
-- Table structure for table `barang`
--

CREATE TABLE IF NOT EXISTS `barang` (
  `kd_barang` varchar(15) NOT NULL,
  `nama_barang` varchar(255) NOT NULL,
  `HJP` varchar(20) NOT NULL,
  `HBP` varchar(20) NOT NULL,
  `min_stock` varchar(20) NOT NULL,
  `max_stock` varchar(20) NOT NULL,
  `satuan` varchar(3) NOT NULL,
  `jmlh_brg` varchar(25) NOT NULL,
  `diskon` varchar(25) NOT NULL,
  `ppn` varchar(25) NOT NULL,
  PRIMARY KEY (`kd_barang`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `barang`
--

INSERT INTO `barang` (`kd_barang`, `nama_barang`, `HJP`, `HBP`, `min_stock`, `max_stock`, `satuan`, `jmlh_brg`, `diskon`, `ppn`) VALUES
('1111', 'Kulkas', '1300000', '1200000', '2', '10', 'Unt', '23.0', '0', '0'),
('1222', 'Kulkas', '1300000', '1200000', '2', '6', 'Box', '4', '0', '0');

-- --------------------------------------------------------

--
-- Table structure for table `jual`
--

CREATE TABLE IF NOT EXISTS `jual` (
  `no_invoice` varchar(5) NOT NULL,
  `kode_barang` varchar(10) NOT NULL,
  `total` int(11) NOT NULL,
  `tanggal_keluar` date NOT NULL,
  UNIQUE KEY `no_invoice` (`no_invoice`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `jual`
--

INSERT INTO `jual` (`no_invoice`, `kode_barang`, `total`, `tanggal_keluar`) VALUES
('q', '2', 3, '2012-05-17'),
('', '1111', 0, '2012-05-28'),
('1', '1111', 2, '2012-05-28'),
('12', '1111', 2, '2012-05-28'),
('3', '1111', 2, '2012-05-28'),
('121', '1111', 2, '2012-05-28'),
('2321', '1111', 0, '2012-05-28'),
('2131', '1111', 2, '2012-05-28'),
('212', '1111', 0, '2012-05-28'),
('2121', '1111', 0, '2012-05-28'),
('212a', '1111', 2, '2012-05-28'),
('122', '1111', 2, '2012-05-28'),
('1222', '1111', 2, '2012-05-28'),
('asd', '1111', 0, '2012-05-28'),
('sda', '1111', 0, '2012-05-28'),
('qw', '1111', 0, '2012-05-28'),
('qw1', '1111', 5, '2012-05-28');

-- --------------------------------------------------------

--
-- Table structure for table `kas`
--

CREATE TABLE IF NOT EXISTS `kas` (
  `no_kas` int(20) NOT NULL AUTO_INCREMENT,
  `tgl_trans` date NOT NULL,
  `saldo_debit` varchar(255) DEFAULT NULL,
  `saldo_kredit` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`no_kas`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=9 ;

--
-- Dumping data for table `kas`
--

INSERT INTO `kas` (`no_kas`, `tgl_trans`, `saldo_debit`, `saldo_kredit`) VALUES
(2, '2012-05-28', '2600000.0', '2600000.0'),
(3, '2012-05-28', '5200000.0', NULL),
(4, '2012-05-28', '5200000.0', NULL),
(5, '2012-05-28', '5200000.0', NULL),
(6, '2012-05-28', '7800000.0', NULL),
(7, '2012-05-28', '1.04E7', NULL),
(8, '2012-05-28', '2.6E7', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `kasir`
--

CREATE TABLE IF NOT EXISTS `kasir` (
  `no_kasir` varchar(15) NOT NULL,
  `nama_kasir` varchar(255) NOT NULL,
  `jenkel` varchar(15) NOT NULL,
  `alamat` text NOT NULL,
  `telepon` varchar(15) NOT NULL,
  `kota` varchar(255) NOT NULL,
  PRIMARY KEY (`no_kasir`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `kasir`
--


-- --------------------------------------------------------

--
-- Table structure for table `pegawai`
--

CREATE TABLE IF NOT EXISTS `pegawai` (
  `no_pegawai` varchar(15) NOT NULL,
  `nama_pegawai` varchar(255) NOT NULL,
  `alamat` text NOT NULL,
  `kota` varchar(255) NOT NULL,
  `telepon` varchar(15) NOT NULL,
  `jenkel` varchar(15) NOT NULL,
  PRIMARY KEY (`no_pegawai`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pegawai`
--


-- --------------------------------------------------------

--
-- Table structure for table `suplier`
--

CREATE TABLE IF NOT EXISTS `suplier` (
  `kd_suplier` varchar(20) NOT NULL,
  `nama_suplier` varchar(255) NOT NULL,
  `jenkel` varchar(6) NOT NULL,
  `alamat` text NOT NULL,
  `kota` varchar(255) NOT NULL,
  `telepon` varchar(20) NOT NULL,
  PRIMARY KEY (`kd_suplier`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `suplier`
--


-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `userid` varchar(255) NOT NULL,
  `pass` varchar(255) NOT NULL,
  `status` int(1) NOT NULL,
  UNIQUE KEY `userid` (`userid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`userid`, `pass`, `status`) VALUES
('7d429d9f79dc5817da98e9dafaf7ceea6ce3999e', 'a14861a9b7fcaf0e7abae833329cd6f0', 2),
('c2851c38bec76bc2bb6b17d2468753c6c7b7a02a', 'f82e1afa853a4073ca41eae5d74da510', 0),
('0453ac51118e6cac5b068a39906fe533bb4535ee', 'ebd5a8107f770e8e05bcb3b3a5a0f016', 1);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
